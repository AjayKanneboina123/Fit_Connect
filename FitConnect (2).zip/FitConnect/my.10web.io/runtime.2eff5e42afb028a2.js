(() => {
    "use strict";
    var e, h = {},
        g = {};

    function r(e) {
        var n = g[e];
        if (void 0 !== n) return n.exports;
        var t = g[e] = {
            id: e,
            loaded: !1,
            exports: {}
        };
        return h[e].call(t.exports, t, t.exports, r), t.loaded = !0, t.exports
    }
    r.m = h, r.amdO = {}, e = [], r.O = (n, t, o, f) => {
        if (!t) {
            var a = 1 / 0;
            for (i = 0; i < e.length; i++) {
                for (var [t, o, f] = e[i], l = !0, d = 0; d < t.length; d++)(!1 & f || a >= f) && Object.keys(r.O).every(b => r.O[b](t[d])) ? t.splice(d--, 1) : (l = !1, f < a && (a = f));
                if (l) {
                    e.splice(i--, 1);
                    var c = o();
                    void 0 !== c && (n = c)
                }
            }
            return n
        }
        f = f || 0;
        for (var i = e.length; i > 0 && e[i - 1][2] > f; i--) e[i] = e[i - 1];
        e[i] = [t, o, f]
    }, r.n = e => {
        var n = e && e.__esModule ? () => e.default : () => e;
        return r.d(n, {
            a: n
        }), n
    }, (() => {
        var n, e = Object.getPrototypeOf ? t => Object.getPrototypeOf(t) : t => t.__proto__;
        r.t = function(t, o) {
            if (1 & o && (t = this(t)), 8 & o || "object" == typeof t && t && (4 & o && t.__esModule || 16 & o && "function" == typeof t.then)) return t;
            var f = Object.create(null);
            r.r(f);
            var i = {};
            n = n || [null, e({}), e([]), e(e)];
            for (var a = 2 & o && t;
                "object" == typeof a && !~n.indexOf(a); a = e(a)) Object.getOwnPropertyNames(a).forEach(l => i[l] = () => t[l]);
            return i.default = () => t, r.d(f, i), f
        }
    })(), r.d = (e, n) => {
        for (var t in n) r.o(n, t) && !r.o(e, t) && Object.defineProperty(e, t, {
            enumerable: !0,
            get: n[t]
        })
    }, r.f = {}, r.e = e => Promise.all(Object.keys(r.f).reduce((n, t) => (r.f[t](e, n), n), [])), r.u = e => (76 === e ? "common" : e) + "." + {
        50: "bb1492dd3277f20f",
        76: "0a5e0421e746db04",
        96: "ae8290214c7e7b74",
        154: "443b19a2e8b8f494",
        418: "d698f0b0d0a9575c",
        517: "5a3813894cccaffd",
        692: "53694cec9d549c1a",
        935: "e02f5ac3ccbf34ca"
    }[e] + ".js", r.miniCssF = e => {}, r.hmd = e => ((e = Object.create(e)).children || (e.children = []), Object.defineProperty(e, "exports", {
        enumerable: !0,
        set: () => {
            throw new Error("ES Modules may not assign module.exports or exports.*, Use ESM export syntax, instead: " + e.id)
        }
    }), e), r.o = (e, n) => Object.prototype.hasOwnProperty.call(e, n), (() => {
        var e = {},
            n = "dashboard:";
        r.l = (t, o, f, i) => {
            if (e[t]) e[t].push(o);
            else {
                var a, l;
                if (void 0 !== f)
                    for (var d = document.getElementsByTagName("script"), c = 0; c < d.length; c++) {
                        var s = d[c];
                        if (s.getAttribute("src") == t || s.getAttribute("data-webpack") == n + f) {
                            a = s;
                            break
                        }
                    }
                a || (l = !0, (a = document.createElement("script")).type = "module", a.charset = "utf-8", a.timeout = 120, r.nc && a.setAttribute("nonce", r.nc), a.setAttribute("data-webpack", n + f), a.src = r.tu(t)), e[t] = [o];
                var u = (v, b) => {
                        a.onerror = a.onload = null, clearTimeout(p);
                        var y = e[t];
                        if (delete e[t], a.parentNode && a.parentNode.removeChild(a), y && y.forEach(_ => _(b)), v) return v(b)
                    },
                    p = setTimeout(u.bind(null, void 0, {
                        type: "timeout",
                        target: a
                    }), 12e4);
                a.onerror = u.bind(null, a.onerror), a.onload = u.bind(null, a.onload), l && document.head.appendChild(a)
            }
        }
    })(), r.r = e => {
        typeof Symbol < "u" && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, {
            value: "Module"
        }), Object.defineProperty(e, "__esModule", {
            value: !0
        })
    }, r.nmd = e => (e.paths = [], e.children || (e.children = []), e), (() => {
        var e;
        r.tt = () => (void 0 === e && (e = {
            createScriptURL: n => n
        }, typeof trustedTypes < "u" && trustedTypes.createPolicy && (e = trustedTypes.createPolicy("angular#bundler", e))), e)
    })(), r.tu = e => r.tt().createScriptURL(e), r.p = "", (() => {
        var e = {
            121: 0
        };
        r.f.j = (o, f) => {
            var i = r.o(e, o) ? e[o] : void 0;
            if (0 !== i)
                if (i) f.push(i[2]);
                else if (121 != o) {
                var a = new Promise((s, u) => i = e[o] = [s, u]);
                f.push(i[2] = a);
                var l = r.p + r.u(o),
                    d = new Error;
                r.l(l, s => {
                    if (r.o(e, o) && (0 !== (i = e[o]) && (e[o] = void 0), i)) {
                        var u = s && ("load" === s.type ? "missing" : s.type),
                            p = s && s.target && s.target.src;
                        d.message = "Loading chunk " + o + " failed.\n(" + u + ": " + p + ")", d.name = "ChunkLoadError", d.type = u, d.request = p, i[1](d)
                    }
                }, "chunk-" + o, o)
            } else e[o] = 0
        }, r.O.j = o => 0 === e[o];
        var n = (o, f) => {
                var d, c, [i, a, l] = f,
                    s = 0;
                if (i.some(p => 0 !== e[p])) {
                    for (d in a) r.o(a, d) && (r.m[d] = a[d]);
                    if (l) var u = l(r)
                }
                for (o && o(f); s < i.length; s++) r.o(e, c = i[s]) && e[c] && e[c][0](), e[c] = 0;
                return r.O(u)
            },
            t = self.webpackChunkdashboard = self.webpackChunkdashboard || [];
        t.forEach(n.bind(null, 0)), t.push = n.bind(null, t.push.bind(t))
    })()
})();
//# sourceMappingURL=runtime.2eff5e42afb028a2.js.map