"use strict";
(self.webpackChunkdashboard = self.webpackChunkdashboard || []).push([
    [692], {
        71692: (Z, b, o) => {
            o.r(b), o.d(b, {
                SinglePageDemoModule: () => V
            });
            var g = o(60316),
                w = o(62326),
                S = o(34456),
                k = o(96575),
                j = o(81245),
                O = o(36203),
                d = o(27356),
                l = o(76693),
                D = o(33900),
                m = o(51567),
                u = o(36647),
                f = o(2435),
                I = o(84205),
                M = o(19999),
                T = o(96303),
                a = o(55386),
                v = o(59172),
                U = o(98125),
                E = o(69943),
                z = o(61588),
                t = o(68559),
                G = o(79431),
                L = o(30786),
                $ = o(72233),
                X = o(14474),
                N = o(99787),
                W = o(13790),
                B = o(27755),
                F = o(1019);
            const Y = s => ({
                opened: s
            });

            function R(s, J) {
                if (1 & s && (t.j41(0, "div"), t.nrm(1, "span", 17), t.k0s()), 2 & s) {
                    const e = t.XpG(2);
                    t.ZvI("link-copied-tooltip ", e.linkCopied, ""), t.R7$(), t.Y8G("innerHtml", e.linkCopied ? "Copied" : "Copy", t.npT)
                }
            }

            function Q(s, J) {
                if (1 & s) {
                    const e = t.RV6();
                    t.j41(0, "div", 1)(1, "div", 2), t.nrm(2, "i", 3), t.j41(3, "div", 4)(4, "div", 5), t.bIt("click", function() {
                        t.eBV(e);
                        const n = t.XpG();
                        return t.Njj(n.profileOpened = !n.profileOpened)
                    }), t.j41(5, "a", 6), t.nrm(6, "img", 7), t.k0s()(), t.j41(7, "div", 8)(8, "div", 9)(9, "a", 10), t.nrm(10, "img", 7), t.k0s(), t.j41(11, "div"), t.nrm(12, "b", 11)(13, "p", 11), t.k0s()(), t.j41(14, "div", 12), t.bIt("click", function() {
                        t.eBV(e);
                        const n = t.XpG();
                        return t.Njj(n.signOut())
                    }), t.j41(15, "span", 13), t.EFF(16, "Sign out"), t.k0s()()()()(), t.j41(17, "div", 14)(18, "div", 15)(19, "div", 16), t.nrm(20, "h1", 17), t.j41(21, "div")(22, "a", 18), t.bIt("click", function() {
                        t.eBV(e);
                        const n = t.XpG();
                        return t.Njj(n.openIframe(n.demoWebsitePreviewUrl))
                    }), t.nrm(23, "span", 17), t.k0s(), t.j41(24, "span", 19), t.bIt("click", function() {
                        t.eBV(e);
                        const n = t.XpG();
                        return t.Njj(n.copyLink())
                    }), t.nrm(25, "i", 20), t.k0s(), t.DNE(26, R, 2, 4, "div", 21), t.k0s()(), t.j41(27, "div", 22)(28, "a", 23), t.bIt("click", function() {
                        t.eBV(e);
                        const n = t.XpG();
                        return t.Njj(n.openIframe(n.demoWebsitePreviewUrl))
                    }), t.j41(29, "span"), t.EFF(30, "Preview"), t.k0s()()()(), t.j41(31, "div", 24)(32, "a", 25), t.bIt("click", function() {
                        t.eBV(e);
                        const n = t.XpG();
                        return t.Njj(n.openIframe(n.demoWebsitePreviewUrl))
                    }), t.nrm(33, "img", 26), t.k0s()(), t.j41(34, "div", 27)(35, "button", 28), t.bIt("click", function() {
                        t.eBV(e);
                        const n = t.XpG();
                        return t.Njj(n.showCheckoutDialog())
                    }), t.j41(36, "span"), t.EFF(37, "Edit Your Website"), t.k0s()()()()()
                }
                if (2 & s) {
                    const e = t.XpG();
                    t.R7$(6), t.Y8G("fallback", "profile-only-neww.png")("email", null == e.user ? null : e.user.email), t.R7$(), t.Y8G("ngClass", t.eq3(11, Y, e.profileOpened)), t.R7$(3), t.Y8G("fallback", "profile-only-neww.png")("email", null == e.user ? null : e.user.email), t.R7$(2), t.Y8G("innerHTML", e.user ? (null == e.user ? null : e.user.firstName) + " " + (null == e.user ? null : e.user.lastName) : "", t.npT), t.R7$(), t.Y8G("innerHTML", null == e.user ? null : e.user.email, t.npT), t.R7$(7), t.Y8G("innerHtml", e.demoWebsite.title, t.npT), t.R7$(3), t.Y8G("innerHtml", e.demoWebsite.site_url, t.npT), t.R7$(), t.Y8G("cbContent", e.demoWebsite.site_url), t.R7$(2), t.Y8G("ngIf", e.linkCopied)
                }
            }
            const H = [{
                path: "",
                component: (() => {
                    class s {
                        constructor(e, i, n, r, c, h, p, P, _, C) {
                            this._store = e, this._authService = i, this._userService = n, this._modalService = r, this._cookieService = c, this._router = h, this._route = p, this._location = P, this._globalEventDispatcher = _, this._googleAnalyticsService = C, this.profileOpened = !1, this.queryParamsActions = !1, this.linkCopied = !1, this._destroyStream$ = new I.B, this.isMobile = window.innerWidth <= 991
                        }
                        ngOnInit() {
                            this.queryParams = this._route.queryParams.value, this._loadData()
                        }
                        openIframe(e) {
                            this._globalEventDispatcher.dispatchEvent(z.c.showDemoPreviewIframe, {
                                showIframe: !0,
                                iframeUrl: e
                            })
                        }
                        _setSubscriptions(e, i, n) {
                            for (const r of e)
                                if (r && (i ? "b" === r.variant : "a" === r.variant) && r[n] && r.plan && "true" === r.plan ? .shortFeatures ? .active && r.category === T.LY.PERSONAL && (1 === r.plan.periodNumber && (this.monthlyPlan = r), 12 === r.plan.periodNumber && (this.yearlyPlan = r), this.monthlyPlan && this.yearlyPlan)) break;
                            this._showUpgradePopup && this.showCheckoutUpgradeDialog()
                        }
                        _getQueryParams(e) {
                            this.queryParamsActions = !0, this._showUpgradePopup = e.showUpgradePopup;
                            const i = e.theme_id || null,
                                n = e.font_family || null,
                                r = e.color_pallet || null;
                            (!a.Q.isNull(i) || !a.Q.isNull(n) || !a.Q.isNull(r)) && this.updateUserLocalStorage(i, n, r);
                            const c = this._router.url.indexOf("?"); - 1 !== c && this._location.replaceState(this._router.url.substring(0, c))
                        }
                        updateUserLocalStorage(e, i, n) {
                            e && (this.userLocalStorage.themeId = e), i && (this.userLocalStorage.fontFamily = i), n && (this.userLocalStorage.colorPallet = n), this._userService.setToLocal(this.userLocalStorage)
                        }
                        showCheckoutUpgradeDialog() {
                            const e = this._modalService.open(U.J);
                            e.componentInstance.monthlyPlan = this.monthlyPlan, e.componentInstance.currentSubscription = this.userSubscription, e.componentInstance.yearlyPlan = this.yearlyPlan, e.componentInstance.isEcommerce = this.isEcommerceWebsite, e.componentInstance.title = this.title, e.componentInstance.currentStep = this._showUpgradePopup ? 2 : 1, this._showUpgradePopup = !1
                        }
                        _loadData() {
                            (0, M.z)([this._store.select(l.$jf).pipe((0, D.Q)(this._destroyStream$), (0, m.p)(e => e), (0, u.n)(() => (0, M.z)([this._store.select(l.wzM), this._store.select(l.hai), this._store.select(l.mOm), this._store.select(l.IwO).pipe((0, m.p)(e => e), (0, u.n)(() => this._store.select(l.t5d())), (0, f.$)())]))), this._store.select(l.kn7).pipe((0, m.p)(e => e), (0, u.n)(() => this._store.select(l.LtP)), (0, f.$)())]).pipe((0, f.$)(([e, i]) => a.Q.isDefined(e[0]) && a.Q.isDefined(e[1]) && a.Q.isDefined(e[2]) && !!e[3] ? .length && a.Q.isDefined(i))).subscribe(([
                                [e, i, n, r], c
                            ]) => {
                                this.user = e, this.userSubscription = i, this.userLocalStorage = n, this.userLocalStorage && !this.queryParamsActions && this._getQueryParams(this.queryParams), this.demoWebsite = c.find(x => x.isAiBuilderDemo);
                                const h = !!this._cookieService.get("db-testing");
                                this.demoWebsitePreviewUrl = `${this.demoWebsite.site_url}?from=websites&client_id=${this.user.id}&domain_id=${E.T.demoDomainId}&first_time` + (h ? "&db-testing" : ""), this.isEcommerceWebsite = c.some(x => !!x.isEcommerceWebsite), this.title = v.l.getText("text_aiBuilder1wfInformativeMobileTitle");
                                const p = this._cookieService.get("db-experiment"),
                                    P = n && !!n.tier1B,
                                    _ = !!p && JSON.parse(p) && JSON.parse(p).t1PExp && "b" === JSON.parse(p).t1PExp,
                                    C = P || _;
                                let y = "isBusiness";
                                this.isEcommerceWebsite && (this.title = v.l.getText("text_aiBuilder1wfEcommerceMobileTitle"), y = "isEcommerce"), this._setSubscriptions(r, C, y)
                            })
                        }
                        ngOnDestroy() {
                            this._destroyStream$.next(!0), this._destroyStream$.complete()
                        }
                        signOut() {
                            this._authService.canLogout() && (typeof window.zE < "u" && window.zE("messenger", "logoutUser"), typeof window.Smooch < "u" && (window.Smooch ? .destroy(), window.Smooch = void 0), this._authService.logoutFromProfile(null, this.user.id, this.userSubscription))
                        }
                        showCheckoutDialog() {
                            this._googleAnalyticsService.sendAnalyticsEventWithCore({
                                eventCategory: "Free Upgrade Offer",
                                eventAction: "Locked button click",
                                eventLabel: "Edit Website(one pager)"
                            }), this.showCheckoutUpgradeDialog()
                        }
                        onDocumentClick(e) {
                            document.querySelector(".user-menu") && document.querySelector(".user-menu").contains(e.target) ? e.stopImmediatePropagation() : this.profileOpened = !1
                        }
                        copyLink() {
                            this._copyLinkTimeout && clearTimeout(this._copyLinkTimeout), this.linkCopied = !0, this._copyLinkTimeout = setTimeout(() => {
                                this.linkCopied = !1
                            }, 800)
                        }
                        static# t = this.\u0275fac = function(i) {
                            return new(i || s)(t.rXU(G.il), t.rXU(L.u), t.rXU($.D), t.rXU(X.L), t.rXU(N.O1), t.rXU(d.Ix), t.rXU(d.nX), t.rXU(g.aZ), t.rXU(W.s), t.rXU(B.p))
                        };
                        static# e = this.\u0275cmp = t.VBU({
                            type: s,
                            selectors: [
                                ["db-single-page-demo"]
                            ],
                            hostBindings: function(i, n) {
                                1 & i && t.bIt("click", function(c) {
                                    return n.onDocumentClick(c)
                                }, !1, t.EBC)
                            },
                            decls: 1,
                            vars: 1,
                            consts: [
                                ["class", "db-single-page-demo", 4, "ngIf"],
                                [1, "db-single-page-demo"],
                                [1, "header"],
                                [1, "db-icon", "db-icon-tenweb-logo"],
                                [1, "user-menu"],
                                [1, "user-menu-profile", 3, "click"],
                                [1, "avatar-button"],
                                ["dbGravatar", "", "size", "100", "alt", "", 3, "fallback", "email"],
                                [1, "user-menu-profile-information", 3, "ngClass"],
                                [1, "db-profile-popup__user-name"],
                                [1, "db-profile-popup__user-profile-picture"],
                                [3, "innerHTML"],
                                [1, "db-profile-popup__user-actions", 3, "click"],
                                [1, "db-profile"],
                                [1, "content"],
                                [1, "db-title-preview"],
                                [1, "title-section"],
                                [3, "innerHtml"],
                                [1, "ds-link", 3, "click"],
                                ["ngxClipboard", "", 1, "db-demo-preview-center-link", 3, "click", "cbContent"],
                                [1, "db-icon", "db-icon-ds-link-l"],
                                [3, "class", 4, "ngIf"],
                                [1, "action-buttons"],
                                [1, "ds-btn", "ds-btn-xxs", 3, "click"],
                                [1, "website-screenshot"],
                                [3, "click"],
                                ["src", "../../../assets/images/common/no_screenshot-demo-mobile-without-shadow.svg", "alt", "Website Screenshot"],
                                [1, "ds-button-wrap"],
                                [1, "ds-btn-purple-blue", "ds-btn-ls", 3, "click"]
                            ],
                            template: function(i, n) {
                                1 & i && t.DNE(0, Q, 38, 13, "div", 0), 2 & i && t.Y8G("ngIf", n.demoWebsite)
                            },
                            dependencies: [g.YU, g.bT, O.Uo, F.e],
                            styles: [".text-center[_ngcontent-%COMP%]{text-align:center!important}.text-left[_ngcontent-%COMP%]{text-align:left!important}.text-right[_ngcontent-%COMP%]{text-align:right!important}.text-bold[_ngcontent-%COMP%], .text-semibold[_ngcontent-%COMP%]{font-weight:700!important}.text-italic[_ngcontent-%COMP%]{font-style:italic!important}.text-underline[_ngcontent-%COMP%]{text-decoration:underline!important}.text-uppercase[_ngcontent-%COMP%]{text-transform:uppercase!important}.text-lowercase[_ngcontent-%COMP%]{text-transform:lowercase!important}.text-capital[_ngcontent-%COMP%]{text-transform:capitalize!important}.text-overflow-ellipsis[_ngcontent-%COMP%], .db-profile-popup__user-name[_ngcontent-%COMP%] > div[_ngcontent-%COMP%]   p[_ngcontent-%COMP%], .db-profile-popup__user-name[_ngcontent-%COMP%] > div[_ngcontent-%COMP%]   b[_ngcontent-%COMP%], .content[_ngcontent-%COMP%] > div[_ngcontent-%COMP%]   .title-section[_ngcontent-%COMP%] > div[_ngcontent-%COMP%] > a[_ngcontent-%COMP%] > span[_ngcontent-%COMP%], .content[_ngcontent-%COMP%] > div[_ngcontent-%COMP%]   .title-section[_ngcontent-%COMP%]   h1[_ngcontent-%COMP%]{overflow:hidden;white-space:nowrap;text-overflow:ellipsis}.user-menu-profile-information[_ngcontent-%COMP%]{font-family:Evergrow Sans,sans-serif;border-radius:6px;border:1px solid #eaeaea;background:#fff;box-shadow:2px 2px 4px #0000001a;position:absolute;z-index:2;top:40px;right:1px;padding:16px 20px 0;color:#000;width:280px;box-sizing:border-box;display:none}.user-menu-profile-information.opened[_ngcontent-%COMP%]{display:flex;align-items:flex-start;justify-content:flex-start;flex-direction:column}.user-menu-profile-information[_ngcontent-%COMP%]   .db-profile-popup__user-actions[_ngcontent-%COMP%]{font-size:0;padding:16px 0;width:100%}.user-menu-profile-information[_ngcontent-%COMP%]   .db-profile-popup__user-actions[_ngcontent-%COMP%]   .db-profile[_ngcontent-%COMP%]{font-size:12px;font-weight:700;line-height:18px;cursor:pointer}.user-menu-profile-information[_ngcontent-%COMP%]   .db-profile-popup__user-actions[_ngcontent-%COMP%]   .db-profile[_ngcontent-%COMP%]:hover{color:#00000080}.content[_ngcontent-%COMP%]{padding:0 20px;display:flex;align-items:center;justify-content:flex-start;flex-direction:column}.content[_ngcontent-%COMP%] > div.db-title-preview[_ngcontent-%COMP%]{display:flex;align-items:center;justify-content:space-between;flex-direction:row;margin:30px 0;gap:36px}.content[_ngcontent-%COMP%] > div[_ngcontent-%COMP%]   .title-section[_ngcontent-%COMP%]   h1[_ngcontent-%COMP%]{margin-bottom:2px;max-width:200px;font-size:16px;font-weight:700;line-height:26px}.content[_ngcontent-%COMP%] > div[_ngcontent-%COMP%]   .title-section[_ngcontent-%COMP%] > div[_ngcontent-%COMP%]{display:flex;align-items:center;justify-content:flex-start;flex-direction:row;position:relative}.content[_ngcontent-%COMP%] > div[_ngcontent-%COMP%]   .title-section[_ngcontent-%COMP%] > div[_ngcontent-%COMP%] > a[_ngcontent-%COMP%]{max-width:170px;display:flex;font-size:12px;font-weight:500;line-height:18px}.content[_ngcontent-%COMP%] > div[_ngcontent-%COMP%]   .title-section[_ngcontent-%COMP%] > div[_ngcontent-%COMP%]   .db-demo-preview-center-link[_ngcontent-%COMP%]{display:flex;align-items:center;justify-content:center;flex-direction:row;width:24px;height:24px;box-sizing:border-box;border-radius:50%;background:#f1f2f3e6;cursor:pointer;margin-left:8px}.content[_ngcontent-%COMP%] > div[_ngcontent-%COMP%]   .title-section[_ngcontent-%COMP%] > div[_ngcontent-%COMP%]   .db-demo-preview-center-link[_ngcontent-%COMP%]:hover   i[_ngcontent-%COMP%]{color:#00000080}.content[_ngcontent-%COMP%] > div[_ngcontent-%COMP%]   .title-section[_ngcontent-%COMP%] > div[_ngcontent-%COMP%]   .db-demo-preview-center-link[_ngcontent-%COMP%]   i[_ngcontent-%COMP%]{font-size:14px;color:#000}.content[_ngcontent-%COMP%] > div[_ngcontent-%COMP%]   .title-section[_ngcontent-%COMP%] > div[_ngcontent-%COMP%]   .link-copied-tooltip[_ngcontent-%COMP%]{position:absolute;right:0;bottom:-38px;display:flex;align-items:center;justify-content:center;flex-direction:row;width:86px;height:30px;padding:6px 12px;box-sizing:border-box;border-radius:6px;background:#000;box-shadow:0 4px 8px #0000001a}.content[_ngcontent-%COMP%] > div[_ngcontent-%COMP%]   .title-section[_ngcontent-%COMP%] > div[_ngcontent-%COMP%]   .link-copied-tooltip[_ngcontent-%COMP%]   span[_ngcontent-%COMP%]{color:#fff;font-size:12px;font-weight:500;line-height:18px}.content[_ngcontent-%COMP%] > div[_ngcontent-%COMP%]   .action-buttons[_ngcontent-%COMP%]   .ds-btn[_ngcontent-%COMP%]   span[_ngcontent-%COMP%]{font-weight:700}.content[_ngcontent-%COMP%]   .website-screenshot[_ngcontent-%COMP%]{border-radius:8px;overflow:hidden;margin-bottom:30px;font-size:0;box-shadow:0 4px 8px #0000001a,0 -3px 4px -2px #0000000f}.content[_ngcontent-%COMP%]   .website-screenshot[_ngcontent-%COMP%]   a[_ngcontent-%COMP%]{font-size:0}.content[_ngcontent-%COMP%]   .website-screenshot[_ngcontent-%COMP%]   a[_ngcontent-%COMP%]   img[_ngcontent-%COMP%]{height:211px;width:336px}.content[_ngcontent-%COMP%]   .ds-button-wrap[_ngcontent-%COMP%]   .ds-btn-purple-blue[_ngcontent-%COMP%]   span[_ngcontent-%COMP%]{font-weight:500}.db-profile-popup__user-name[_ngcontent-%COMP%]{display:flex;align-items:flex-end;justify-content:flex-start;flex-direction:row;border-bottom:1px solid #eaeaea;padding-bottom:16px;width:100%}.db-profile-popup__user-name[_ngcontent-%COMP%]   .db-profile-popup__user-profile-picture[_ngcontent-%COMP%]{display:flex;align-items:center;justify-content:center;flex-direction:row;border-radius:50%;background:#0000001a;padding:8px;box-sizing:border-box;height:36px}.db-profile-popup__user-name[_ngcontent-%COMP%]   .db-profile-popup__user-profile-picture[_ngcontent-%COMP%]   img[_ngcontent-%COMP%]{height:20px;width:20px}.db-profile-popup__user-name[_ngcontent-%COMP%] > div[_ngcontent-%COMP%]{display:flex;align-items:flex-start;justify-content:flex-start;flex-direction:column;margin-left:14px;gap:2px}.db-profile-popup__user-name[_ngcontent-%COMP%] > div[_ngcontent-%COMP%]   b[_ngcontent-%COMP%]{font-size:12px;font-weight:700;line-height:18px;max-width:190px}.db-profile-popup__user-name[_ngcontent-%COMP%] > div[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{font-size:12px;font-weight:500;line-height:18px;max-width:190px;color:#00000080}.db-single-page-demo[_ngcontent-%COMP%]{color:#000}.db-single-page-demo[_ngcontent-%COMP%]   *[_ngcontent-%COMP%]{font-family:Evergrow Sans,sans-serif}.db-single-page-demo[_ngcontent-%COMP%]   .header[_ngcontent-%COMP%]{display:flex;align-items:center;justify-content:space-between;flex-direction:row;padding:12px 20px;border-bottom:1px solid #eaeaea}.db-single-page-demo[_ngcontent-%COMP%]   .header[_ngcontent-%COMP%]   i[_ngcontent-%COMP%]{font-size:20px}.db-single-page-demo[_ngcontent-%COMP%]   .header[_ngcontent-%COMP%]   .user-menu[_ngcontent-%COMP%]{position:relative}.db-single-page-demo[_ngcontent-%COMP%]   .header[_ngcontent-%COMP%]   .user-menu[_ngcontent-%COMP%]   .avatar-button[_ngcontent-%COMP%]{display:flex;align-items:center;justify-content:center;flex-direction:row;border-radius:50%;background:#0000001a;padding:6px;box-sizing:border-box}.db-single-page-demo[_ngcontent-%COMP%]   .header[_ngcontent-%COMP%]   .user-menu[_ngcontent-%COMP%]   .avatar-button[_ngcontent-%COMP%]   img[_ngcontent-%COMP%]{height:18px}"]
                        })
                    }
                    return s
                })()
            }];
            let A = (() => {
                    class s {
                        static# t = this.\u0275fac = function(i) {
                            return new(i || s)
                        };
                        static# e = this.\u0275mod = t.$C({
                            type: s
                        });
                        static# n = this.\u0275inj = t.G2t({
                            imports: [d.iI.forChild(H), d.iI]
                        })
                    }
                    return s
                })(),
                V = (() => {
                    class s {
                        static# t = this.\u0275fac = function(i) {
                            return new(i || s)
                        };
                        static# e = this.\u0275mod = t.$C({
                            type: s
                        });
                        static# n = this.\u0275inj = t.G2t({
                            imports: [g.MD, A, w.s0, S.X1, k.w, j.K, O.FQ]
                        })
                    }
                    return s
                })()
        }
    }
]);
//# sourceMappingURL=692.53694cec9d549c1a.js.map