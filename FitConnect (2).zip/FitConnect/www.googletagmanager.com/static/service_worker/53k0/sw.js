'use strict';
var aa = function(a) {
        function b(d) {
            return a.next(d)
        }

        function c(d) {
            return a.throw(d)
        }
        return new Promise(function(d, e) {
            function f(g) {
                g.done ? d(g.value) : Promise.resolve(g.value).then(b, c).then(f, e)
            }
            f(a.next())
        })
    },
    h = function(a) {
        return aa(a())
    };
/*

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/
var n = {},
    r = null,
    x = function(a) {
        var b = 3;
        b === void 0 && (b = 0);
        w();
        const c = n[b],
            d = Array(Math.floor(a.length / 3)),
            e = c[64] || "";
        let f = 0,
            g = 0;
        for (; f < a.length - 2; f += 3) {
            const p = a[f],
                q = a[f + 1],
                A = a[f + 2],
                v = c[p >> 2],
                m = c[(p & 3) << 4 | q >> 4],
                t = c[(q & 15) << 2 | A >> 6],
                u = c[A & 63];
            d[g++] = "" + v + m + t + u
        }
        let k = 0,
            l = e;
        switch (a.length - f) {
            case 2:
                k = a[f + 1], l = c[(k & 15) << 2] || e;
            case 1:
                const p = a[f];
                d[g] = "" + c[p >> 2] + c[(p & 3) << 4 | k >> 4] + l + e
        }
        return d.join("")
    },
    B = function(a) {
        const b = a.length;
        let c = b * 3 / 4;
        c % 3 ? c = Math.floor(c) : "=.".indexOf(a[b - 1]) != -1 && (c = "=.".indexOf(a[b -
            2]) != -1 ? c - 2 : c - 1);
        const d = new Uint8Array(c);
        let e = 0;
        ba(a, function(f) {
            d[e++] = f
        });
        return e !== c ? d.subarray(0, e) : d
    },
    ba = function(a, b) {
        function c(e) {
            for (; d < a.length;) {
                const f = a.charAt(d++),
                    g = r[f];
                if (g != null) return g;
                if (!/^[\s\xa0]*$/.test(f)) throw Error("Unknown base64 encoding at char: " + f);
            }
            return e
        }
        w();
        let d = 0;
        for (;;) {
            const e = c(-1),
                f = c(0),
                g = c(64),
                k = c(64);
            if (k === 64 && e === -1) break;
            b(e << 2 | f >> 4);
            g != 64 && (b(f << 4 & 240 | g >> 2), k != 64 && b(g << 6 & 192 | k))
        }
    },
    w = function() {
        if (!r) {
            r = {};
            var a = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".split(""),
                b = ["+/=", "+/", "-_=", "-_.", "-_"];
            for (let c = 0; c < 5; c++) {
                const d = a.concat(b[c].split(""));
                n[c] = d;
                for (let e = 0; e < d.length; e++) {
                    const f = d[e];
                    r[f] === void 0 && (r[f] = e)
                }
            }
        }
    };
/*

 Copyright 2020 Google LLC
 SPDX-License-Identifier: Apache-2.0
*/
var C = class extends Error {
    constructor(a) {
        super(a);
        Object.setPrototypeOf(this, C.prototype)
    }
};
C.prototype.name = "SecurityException";
var D = class extends Error {
    constructor(a) {
        super(a);
        Object.setPrototypeOf(this, D.prototype)
    }
};
D.prototype.name = "InvalidArgumentsException";

function F(...a) {
    let b = 0;
    for (let e = 0; e < arguments.length; e++) b += arguments[e].length;
    const c = new Uint8Array(b);
    let d = 0;
    for (let e = 0; e < arguments.length; e++) c.set(arguments[e], d), d += arguments[e].length;
    return c
}

function G(a) {
    const b = a.replace(/-/g, "+").replace(/_/g, "/");
    return H(globalThis.atob(b))
}

function I(a) {
    let b = "";
    for (let c = 0; c < a.length; c += 1) b += String.fromCharCode(a[c]);
    return globalThis.btoa(b).replace(/=/g, "").replace(/\+/g, "-").replace(/\//g, "_")
}

function H(a) {
    const b = [];
    let c = 0;
    for (let d = 0; d < a.length; d++) {
        const e = a.charCodeAt(d);
        b[c++] = e
    }
    return new Uint8Array(b)
};
/*

 Copyright 2022 Google LLC
 SPDX-License-Identifier: Apache-2.0
*/
var ca = function(a, b, c, d) {
        return h(function*() {
            if (c.length < (a.l ? 28 : 16)) throw new C("ciphertext too short");
            if (b.length !== 12) throw new C("IV must be 12 bytes");
            const e = {
                name: "AES-GCM",
                iv: b,
                tagLength: 128
            };
            d && (e.additionalData = d);
            const f = a.l ? new Uint8Array(c.subarray(12)) : c;
            try {
                return new Uint8Array(yield globalThis.crypto.subtle.decrypt(e, a.key, f))
            } catch (g) {
                throw new C(g.toString());
            }
        })
    },
    J = class {
        constructor({
            key: a,
            l: b
        }) {
            this.key = a;
            this.l = b
        }
        encrypt(a, b, c) {
            const d = this;
            return h(function*() {
                if (a.length !==
                    12) throw new C("IV must be 12 bytes");
                const e = {
                    name: "AES-GCM",
                    iv: a,
                    tagLength: 128
                };
                c && (e.additionalData = c);
                const f = yield globalThis.crypto.subtle.encrypt(e, d.key, b);
                return d.l ? F(a, new Uint8Array(f)) : new Uint8Array(f)
            })
        }
    };

function K({
    key: a,
    l: b
}) {
    return h(function*() {
        if (![16, 32].includes(a.length)) throw new D("unsupported AES key size: ${n}");
        const c = yield globalThis.crypto.subtle.importKey("raw", a, {
            name: "AES-GCM",
            length: a.length
        }, !1, ["encrypt", "decrypt"]);
        return new J({
            key: c,
            l: b
        })
    })
};

function N(a) {
    switch (a) {
        case 1:
            return "P-256";
        case 2:
            return "P-384";
        case 3:
            return "P-521"
    }
}

function O(a) {
    switch (a) {
        case "P-256":
            return 1;
        case "P-384":
            return 2;
        case "P-521":
            return 3
    }
    throw new D("unknown curve: " + a);
}

function P(a) {
    switch (a) {
        case 1:
            return 32;
        case 2:
            return 48;
        case 3:
            return 66
    }
}

function da(a, b) {
    return h(function*() {
        const c = a.algorithm.namedCurve;
        if (!c) throw new D("namedCurve must be provided");
        const d = Object.assign({}, {
                "public": b
            }, a.algorithm),
            e = 8 * P(O(c)),
            f = yield globalThis.crypto.subtle.deriveBits(d, a, e);
        return new Uint8Array(f)
    })
}

function ea(a) {
    return h(function*() {
        return yield globalThis.crypto.subtle.generateKey({
            name: "ECDH",
            namedCurve: a
        }, !0, ["deriveKey", "deriveBits"])
    })
}

function fa(a) {
    return h(function*() {
        const b = yield globalThis.crypto.subtle.exportKey("jwk", a);
        if (b.crv === void 0) throw new D("crv must be provided");
        const c = P(O(b.crv));
        if (b.x === void 0) throw new D("x must be provided");
        if (b.y === void 0) throw new D("y must be provided");
        const d = G(b.x);
        if (d.length !== c) throw new D(`x-coordinate byte-length is invalid (got: ${d.length}, want: ${c}).`);
        const e = G(b.y);
        if (e.length !== c) throw new D(`y-coordinate byte-length is invalid (got: ${e.length}, want: ${c}).`);
        return b
    })
}

function ha(a) {
    return h(function*() {
        const b = a.crv;
        if (!b) throw new D("crv must be provided");
        return yield globalThis.crypto.subtle.importKey("jwk", a, {
            name: "ECDH",
            namedCurve: b
        }, !0, [])
    })
};
var ia = Q(1, 0),
    ja = Q(2, 16),
    ka = Q(2, 18),
    la = Q(2, 1),
    ma = Q(2, 3),
    na = Q(2, 1),
    oa = Q(2, 2),
    pa = H("KEM"),
    qa = H("HPKE"),
    ra = H("HPKE-v1");

function Q(a, b) {
    const c = new Uint8Array(a);
    for (let d = 0; d < a; d++) c[d] = b >> 8 * (a - d - 1) & 255;
    return c
}

function ta({
    J: a,
    I: b,
    F: c
}) {
    return F(qa, a, b, c)
}

function ua({
    o: a,
    m: b,
    i: c
}) {
    return F(ra, c, H(a), b)
}

function va({
    s: a,
    info: b,
    i: c,
    length: d
}) {
    return F(Q(2, d), ra, c, H(a), b)
}

function wa(a, b) {
    return h(function*() {
        var c; {
            const d = P(O(a));
            if (b.length !== 1 + 2 * d || b[0] !== 4) throw new C("invalid point");
            c = {
                kty: "EC",
                crv: a,
                x: I(new Uint8Array(b.subarray(1, 1 + d))),
                y: I(new Uint8Array(b.subarray(1 + d, b.length))),
                ext: !0
            }
        }
        return yield ha(c)
    })
}

function xa(a) {
    return h(function*() {
        const b = a.algorithm,
            c = yield fa(a);
        if (!c.crv) throw new C("Curve has to be defined.");
        var d; {
            const e = P(O(b.namedCurve)),
                f = c.x,
                g = c.y;
            if (f === void 0) throw new D("x must be provided");
            if (g === void 0) throw new D("y must be provided");
            const k = new Uint8Array(1 + 2 * e),
                l = G(g),
                p = G(f);
            k.set(l, 1 + 2 * e - l.length);
            k.set(p, 1 + e - p.length);
            k[0] = 4;
            d = k
        }
        return d
    })
};
var ya = class {
    constructor(a) {
        this.A = a
    }
    seal({
        key: a,
        nonce: b,
        L: c,
        B: d
    }) {
        const e = this;
        return h(function*() {
            if (a.length !== e.A) throw new C("Unexpected key length: " + a.length.toString());
            return yield(yield K({
                key: a,
                l: !1
            })).encrypt(b, c, d)
        })
    }
    open({
        key: a,
        nonce: b,
        G: c,
        B: d
    }) {
        const e = this;
        return h(function*() {
            if (a.length !== e.A) throw new C("Unexpected key length: " + a.length.toString());
            return ca(yield K({
                key: a,
                l: !1
            }), b, c, d)
        })
    }
};
var za = class {};

function T(a) {
    if (a == null || !(a instanceof Uint8Array)) throw new D("input must be a non null Uint8Array");
};
var Aa = function(a, b) {
        return h(function*() {
            T(b);
            const c = yield globalThis.crypto.subtle.sign({
                name: "HMAC",
                hash: {
                    name: a.hash
                }
            }, a.key, b);
            return new Uint8Array(c.slice(0, a.g))
        })
    },
    Ba = class extends za {
        constructor(a, b, c) {
            super();
            this.hash = a;
            this.key = b;
            this.g = c
        }
    };

function Ca(a, b, c) {
    return h(function*() {
        T(b);
        if (!Number.isInteger(c)) throw new D("invalid tag size, must be an integer");
        if (c < 10) throw new D("tag too short, must be at least " + (10).toString() + " bytes");
        switch (a) {
            case "SHA-1":
                if (c > 20) throw new D("tag too long, must not be larger than 20 bytes");
                break;
            case "SHA-256":
                if (c > 32) throw new D("tag too long, must not be larger than 32 bytes");
                break;
            case "SHA-384":
                if (c > 48) throw new D("tag too long, must not be larger than 48 bytes");
                break;
            case "SHA-512":
                if (c >
                    64) throw new D("tag too long, must not be larger than 64 bytes");
                break;
            default:
                throw new D(a + " is not supported");
        }
        const d = yield globalThis.crypto.subtle.importKey("raw", b, {
            name: "HMAC",
            hash: {
                name: a
            },
            length: b.length * 8
        }, !1, ["sign", "verify"]);
        return new Ba(a, d, c)
    })
};
var Da = function(a, b, c) {
        return h(function*() {
            T(b);
            const d = U(a);
            let e;
            ((e = c) == null ? 0 : e.length) || (c = new Uint8Array(d));
            T(c);
            return yield Aa(yield Ca(a.u, c, d), b)
        })
    },
    V = function(a, {
        m: b,
        o: c,
        i: d,
        salt: e
    }) {
        return h(function*() {
            return yield Da(a, ua({
                o: c,
                m: b,
                i: d
            }), e)
        })
    },
    Ea = function(a, b, c, d) {
        return h(function*() {
            if (!Number.isInteger(d)) throw new C("length must be an integer");
            if (d <= 0) throw new C("length must be positive");
            const e = U(a);
            if (d > 255 * e) throw new C("length too large");
            T(c);
            const f = yield Ca(a.u, b, e);
            let g =
                1,
                k = 0,
                l = new Uint8Array(0);
            const p = new Uint8Array(d);
            for (;;) {
                const q = new Uint8Array(l.length + c.length + 1);
                q.set(l, 0);
                q.set(c, l.length);
                q[q.length - 1] = g;
                l = yield Aa(f, q);
                if (k + l.length < d) p.set(l, k), k += l.length, g++;
                else {
                    p.set(l.subarray(0, d - k), k);
                    break
                }
            }
            return p
        })
    },
    Fa = function(a, {
        D: b,
        info: c,
        s: d,
        i: e,
        length: f
    }) {
        return h(function*() {
            return yield Ea(a, b, va({
                s: d,
                info: c,
                i: e,
                length: f
            }), f)
        })
    },
    Ga = function(a, {
        m: b,
        o: c,
        info: d,
        s: e,
        i: f,
        length: g,
        salt: k
    }) {
        return h(function*() {
            const l = yield Da(a, ua({
                o: c,
                m: b,
                i: f
            }), k);
            return yield Ea(a,
                l, va({
                    s: e,
                    info: d,
                    i: f,
                    length: g
                }), g)
        })
    },
    U = function(a) {
        switch (a.u) {
            case "SHA-256":
                return 32;
            case "SHA-512":
                return 64
        }
    },
    W = class {
        constructor(a) {
            this.u = a
        }
    };
var Ha = function(a) {
        var b = a.g;
        const c = new Uint8Array(12);
        for (let f = 0; f < 12; f++) c[f] = Number(b >> BigInt(8 * (12 - f - 1))) & 255;
        var d = a.h;
        if (d.length !== c.length) throw new D("Both byte arrays should be of the same length");
        const e = new Uint8Array(d.length);
        for (let f = 0; f < e.length; f++) e[f] = d[f] ^ c[f];
        if (a.g >= a.j) throw new C("message limit reached");
        a.g += BigInt(1);
        return e
    },
    Ia = class {
        constructor(a, b, c, d) {
            this.C = a;
            this.key = b;
            this.h = c;
            this.aead = d;
            this.g = BigInt(0);
            this.j = (BigInt(1) << BigInt(96)) - BigInt(1)
        }
        seal(a, b) {
            const c =
                this;
            return h(function*() {
                const d = Ha(c);
                return yield c.aead.seal({
                    key: c.key,
                    nonce: d,
                    L: a,
                    B: b
                })
            })
        }
        open(a, b) {
            const c = this;
            return h(function*() {
                const d = Ha(c);
                return c.aead.open({
                    key: c.key,
                    nonce: d,
                    G: a,
                    B: b
                })
            })
        }
    };

function Ja(a, b, c, d, e, f) {
    return h(function*() {
        var g;
        a: {
            switch (e.A) {
                case 16:
                    g = na;
                    break a;
                case 32:
                    g = oa;
                    break a
            }
            g = void 0
        }
        var k;
        a: {
            switch (d.u) {
                case "SHA-256":
                    k = la;
                    break a;
                case "SHA-512":
                    k = ma;
                    break a
            }
            k = void 0
        }
        const l = ta({
                J: Ka(c),
                I: k,
                F: g
            }),
            p = V(d, {
                m: new Uint8Array(0),
                o: "psk_id_hash",
                i: l
            }),
            q = yield V(d, {
                m: f,
                o: "info_hash",
                i: l
            }), A = yield p, v = F(ia, A, q), m = yield V(d, {
                m: new Uint8Array(0),
                o: "secret",
                i: l,
                salt: b
            }), t = Fa(d, {
                D: m,
                info: v,
                s: "key",
                i: l,
                length: e.A
            }), u = yield Fa(d, {
                    D: m,
                    info: v,
                    s: "base_nonce",
                    i: l,
                    length: 12
                }), E =
                yield t;
        return new Ia(a, E, u, e)
    })
}

function La(a, b, c, d, e) {
    return h(function*() {
        const f = yield Ma(b, a);
        return yield Ja(f.C, f.M, b, c, d, e)
    })
};
var Na = function(a) {
        return h(function*() {
            return yield xa(a.publicKey)
        })
    },
    Oa = class {
        constructor(a, b) {
            this.privateKey = a;
            this.publicKey = b
        }
    };

function Pa(a) {
    return h(function*() {
        Qa(a.privateKey, "private");
        Qa(a.publicKey, "public");
        return new Oa(a.privateKey, a.publicKey)
    })
}

function Qa(a, b) {
    if (b !== a.type) throw new D(`keyPair ${b} key was of type ${a.type}`);
    const c = a.algorithm;
    if ("ECDH" !== c.name) throw new D(`keyPair ${b} key should be ECDH but found ${c.name}`);
};
var Sa = function(a) {
        switch (a) {
            case 1:
                return new Ra(new W("SHA-256"), 1);
            case 3:
                return new Ra(new W("SHA-512"), 3)
        }
    },
    Ka = function(a) {
        switch (a.g) {
            case 1:
                return ja;
            case 3:
                return ka
        }
    },
    Ma = function(a, b) {
        return h(function*() {
            const c = yield ea(N(a.g));
            return yield a.h(b, yield Pa(c))
        })
    },
    Ta = function(a, b, c, d) {
        return h(function*() {
            const e = F(c, d),
                f = F(pa, Ka(a));
            return yield Ga(a.j, {
                m: b,
                o: "eae_prk",
                info: e,
                s: "shared_secret",
                i: f,
                length: U(a.j)
            })
        })
    },
    Ra = class {
        constructor(a, b) {
            this.j = a;
            this.g = b;
            this.TEST_ONLY = this.h
        }
        h(a, b) {
            const c =
                this;
            return h(function*() {
                const d = yield wa(N(c.g), a), e = da(b.privateKey, d), f = yield Na(b), g = yield e;
                return {
                    M: yield Ta(c, g, f, a), C: f
                }
            })
        }
    };
/*

 Copyright 2024 Google LLC
 SPDX-License-Identifier: Apache-2.0
*/
function Ua(a, b) {
    var c;
    c || (c = new Uint8Array(0));
    let d, e, f;
    switch (a) {
        case 1:
            d = Sa(1);
            e = new W("SHA-256");
            f = new ya(16);
            break;
        case 2:
            d = Sa(3);
            e = new W("SHA-512");
            f = new ya(32);
            break;
        default:
            throw new C(`Unknown HPKE parameters: ${a}`);
    }
    let g = La(b, d, e, f, c);
    return k => h(function*() {
        if (!g) throw new C("Context has already been used");
        const l = g;
        g = null;
        const p = yield l, q = yield p.seal(k, new Uint8Array(0));
        return F(p.C, q)
    })
};
var Va = function(a, b) {
        return h(function*() {
            if (a.status) return X(a.status);
            try {
                const e = B(a.j(b)),
                    f = yield a.context(e);
                var c;
                if (f.length <= 8192) c = String.fromCharCode.apply(null, f);
                else {
                    var d = "";
                    for (let k = 0; k < f.length; k += 8192) d += String.fromCharCode.apply(null, Array.prototype.slice.call(f, k, k + 8192));
                    c = d
                }
                let g = a.j(c);
                g = g.replace(/\//g, "_");
                g = g.replace(/\+/g, "-");
                return X(0, g)
            } catch (e) {
                return X(6)
            }
        })
    },
    Xa = class {
        constructor(a, b) {
            this.g = 0;
            this.context = () => h(function*() {
                return new Uint8Array(0)
            });
            this.j = e => b(e);
            if (a) {
                this.K = a.id;
                var c = a.hpkePublicKey.params.kdf,
                    d = a.hpkePublicKey.params.aead;
                if (a.hpkePublicKey.params.kem === "DHKEM_P256_HKDF_SHA256" && c === "HKDF_SHA256" && d === "AES_128_GCM") {
                    this.h = 1;
                    this.v = a;
                    try {
                        let e;
                        const f = B((e = this.v) == null ? void 0 : e.hpkePublicKey.publicKey);
                        f && this.h ? this.context = Ua(this.h, f) : this.status = 11
                    } catch (e) {
                        this.status = 6
                    }
                } else this.status = 7
            } else this.status = 8
        }
        setTimeout(a) {
            this.g = a
        }
        encrypt(a) {
            const b = Va(this, a);
            return this.g ? Promise.race([b, Wa(this.g).then(() => X(14))]) : b
        }
        getEncryptionKeyId() {
            return this.K
        }
    };

function X(a, b) {
    return a === 0 ? {
        cipherText: b,
        status: a
    } : {
        status: a
    }
}

function Wa(a) {
    return new Promise(b => void setTimeout(b, a))
};

function Ya(a) {
    switch (a) {
        case 0:
            break;
        case 9:
            return "e4";
        case 6:
            return "e5";
        case 14:
            return "e6";
        default:
            return "e7"
    }
};
const Za = /^[0-9A-Fa-f]{64}$/;

function $a(a) {
    try {
        return (new TextEncoder).encode(a)
    } catch (b) {
        const c = [];
        for (let d = 0; d < a.length; d++) {
            let e = a.charCodeAt(d);
            e < 128 ? c.push(e) : e < 2048 ? c.push(192 | e >> 6, 128 | e & 63) : e < 55296 || e >= 57344 ? c.push(224 | e >> 12, 128 | e >> 6 & 63, 128 | e & 63) : (e = 65536 + ((e & 1023) << 10 | a.charCodeAt(++d) & 1023), c.push(240 | e >> 18, 128 | e >> 12 & 63, 128 | e >> 6 & 63, 128 | e & 63))
        }
        return new Uint8Array(c)
    }
}

function ab(a, b) {
    if (a === "" || a === "e0") return Promise.resolve(a);
    let c;
    if ((c = b.crypto) == null ? 0 : c.subtle) {
        if (Za.test(a)) return Promise.resolve(a);
        try {
            const d = $a(a);
            return b.crypto.subtle.digest("SHA-256", d).then(e => {
                const f = Array.from(new Uint8Array(e)).map(g => String.fromCharCode(g)).join("");
                return b.btoa(f).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "")
            }).catch(() => "e2")
        } catch (d) {
            return Promise.resolve("e2")
        }
    } else return Promise.resolve("e1")
};
var bb = class {};
var cb = class extends bb {
    constructor(a) {
        super();
        this.key = a;
        this.g = new J({
            key: a,
            l: !0
        })
    }
    encrypt(a, b) {
        const c = this;
        return h(function*() {
            if (!Number.isInteger(12)) throw new D("n must be a nonnegative integer");
            const d = new Uint8Array(12);
            globalThis.crypto.getRandomValues(d);
            return c.g.encrypt(d, a, b)
        })
    }
};
const Y = {};

function db(a) {
    var b = globalThis.btoa;
    Y[a] = Y[a] || eb(a);
    const c = fb(),
        d = c.then(f => gb(f)),
        e = Promise.all([Y[a], d]).then(([f, g]) => hb(f, g));
    return {
        encryptMessage: f => h(function*() {
            const g = (new cb(yield c)).encrypt(B(b(f)));
            return {
                encryptedExportedAesKeyAsBase64: x(new Uint8Array(yield e)),
                encryptedPayloadAsBase64: x(yield g)
            }
        })
    }
}

function fb() {
    return h(function*() {
        return globalThis.crypto.subtle.generateKey({
            name: "AES-GCM",
            length: 256
        }, !0, ["encrypt", "decrypt"])
    })
}

function gb(a) {
    return h(function*() {
        return globalThis.crypto.subtle.exportKey("raw", a)
    })
}

function hb(a, b) {
    return h(function*() {
        return globalThis.crypto.subtle.encrypt({
            name: "RSA-OAEP"
        }, a, b)
    })
}

function eb(a) {
    return h(function*() {
        return globalThis.crypto.subtle.importKey("spki", B(a), {
            name: "RSA-OAEP",
            hash: {
                name: "SHA-256"
            }
        }, !1, ["encrypt"])
    })
};
/*
 jQuery (c) 2005, 2012 jQuery Foundation, Inc. jquery.org/license.
*/
var ib = /\[object (Boolean|Number|String|Function|Array|Date|RegExp)\]/,
    jb = function(a) {
        var b;
        if (!(b = !a)) {
            var c;
            if (a == null) c = String(a);
            else {
                var d = ib.exec(Object.prototype.toString.call(Object(a)));
                c = d ? d[1].toLowerCase() : "object"
            }
            b = c != "object"
        }
        if (b || a.nodeType || a == a.window) return !1;
        try {
            if (a.constructor && !Object.prototype.hasOwnProperty.call(Object(a), "constructor") && !Object.prototype.hasOwnProperty.call(Object(a.constructor.prototype), "isPrototypeOf")) return !1
        } catch (f) {
            return !1
        }
        for (var e in a);
        return e ===
            void 0 || Object.prototype.hasOwnProperty.call(Object(a), e)
    };
var kb = function(a, b) {
        b = a.g + b;
        let c = b.indexOf("\n\n");
        for (; c !== -1;) {
            var d = a,
                e;
            a: {
                const [k, l] = b.substring(0, c).split("\n");
                if (k.indexOf("event: message") === 0 && l.indexOf("data: ") === 0) try {
                    e = JSON.parse(l.substring(l.indexOf(":") + 1));
                    break a
                } catch (p) {}
                e = void 0
            }
            var f = d,
                g = e;
            g && (Z(g.send_pixel, g.options, f.h), Z(g.create_iframe, g.options, f.j), Z(g.fetch, g.options, f.v));
            b = b.substring(c + 2);
            c = b.indexOf("\n\n")
        }
        a.g = b
    },
    lb = class {
        constructor(a) {
            this.h = a;
            this.g = ""
        }
    };

function Z(a, b, c) {
    if (a && c) {
        var d = a || [];
        if (Array.isArray(d)) {
            var e = jb(b) ? b : {};
            for (const f of d) c(f, e)
        }
    }
};
var mb = {
    N: 0,
    O: 1,
    0: "GET",
    1: "POST"
};
var ob = function(a, b, c) {
        return h(function*() {
            var d;
            a: {
                try {
                    const g = JSON.parse(c.encryptionKeyString || "").keys,
                        k = g[Math.floor(Math.random() * g.length)];
                    d = k && k.hpkePublicKey && k.hpkePublicKey.params && k.hpkePublicKey.params.kem && k.hpkePublicKey.params.kdf && k.hpkePublicKey.params.aead && k.hpkePublicKey.version !== void 0 && k.id && k.hpkePublicKey.publicKey ? k : void 0;
                    break a
                } catch (g) {}
                d = void 0
            }
            const e = d,
                f = new Xa(e, a.g.btoa);
            return nb(a, a.g.performance.now(), (e == null ? void 0 : e.id) || "undefined", f.encrypt(b))
        })
    },
    pb =
    function(a, b, c) {
        return h(function*() {
            return nb(a, a.g.performance.now(), "unknown", db(c.encryptionKeyString || "").encryptMessage(b).then(d => ({
                cipherText: d.encryptedPayloadAsBase64 + "!" + d.encryptedExportedAesKeyAsBase64,
                status: 0
            })))
        })
    },
    sb = function(a, b) {
        return h(function*() {
            if (!b.url) return {
                failureType: 9,
                command: 0,
                data: "url required."
            };
            const c = yield qb(a, b);
            if ("failureType" in c) return c;
            yield rb(a, c, b);
            return c
        })
    },
    tb = function(a, b, c, d) {
        h(function*() {
            let e;
            const f = b.commandType,
                g = b.params;
            switch (f) {
                case 0:
                    e =
                        yield sb(a, g);
                    break;
                default:
                    e = {
                        failureType: 8,
                        command: f,
                        data: `Command with type ${f} unknown.`
                    }
            }
            "failureType" in e ? d(e) : c(e)
        })
    },
    qb = function(a, b) {
        return h(function*() {
            function c(m) {
                return h(function*() {
                    const [t, u] = m.split("|");
                    let [E, L] = t.split("."), y = L, z = k[E];
                    z || (z = t, y = "");
                    const S = M => h(function*() {
                        try {
                            return yield A(u)(M)
                        } catch (R) {
                            throw new ub(R.message);
                        }
                    });
                    if (!y) {
                        if (typeof z === "string") return yield S(z);
                        const M = z,
                            R = Object.keys(M).map(sa => h(function*() {
                                const wb = yield S(M[sa]);
                                return `${sa}=${wb}`
                            }));
                        return (yield Promise.all(R)).join("&")
                    }
                    return typeof z === "object" && z[y] ? yield S(z[y]): m
                })
            }

            function d(m) {
                return h(function*() {
                    let t, u = "";
                    for (; m.match(q) && u !== m;) {
                        u = m;
                        t = m.matchAll(q);
                        const E = [...t].map(y => c(y[1])),
                            L = yield Promise.all(E);
                        L.length !== 0 && (m = m.replace(q, y => L.shift() || y))
                    }
                    return m
                })
            }
            let {
                url: e,
                body: f
            } = b;
            const {
                attributionReporting: g,
                templates: k,
                processResponse: l,
                method: p = 0
            } = b, q = RegExp("\\${([^${}]*?)}", "g"), A = m => {
                if (m == null) return u => h(function*() {
                    return u
                });
                const t = a.h[m];
                if (t == null) throw Error(`Unknown filter: ${m}`);
                return u => h(function*() {
                    return yield t(u, b)
                })
            };
            try {
                e = yield d(e), f = f ? yield d(f): void 0
            } catch (m) {
                return {
                    failureType: 9,
                    command: 0,
                    data: `Failed to inject template values: ${m}`
                }
            }
            const v = {
                method: mb[p],
                credentials: "include",
                body: p === 1 ? f : void 0,
                keepalive: !0,
                redirect: "follow"
            };
            l || (v.mode = "no-cors");
            g && (v.attributionReporting = {
                eventSourceEligible: !1,
                triggerEligible: !0
            });
            try {
                const m = yield a.g.fetch(e, v);
                return l && !m.ok ? {
                    failureType: 9,
                    command: 0,
                    data: "Fetch failed"
                } : {
                    data: l ? yield m.text(): e
                }
            } catch (m) {
                return {
                    failureType: 9,
                    command: 0,
                    data: `Fetch failed: ${m}`
                }
            }
        })
    },
    rb = function(a, b, c) {
        return h(function*() {
            if (c.processResponse) {
                var d = [];
                kb(new lb((e, f) => {
                    d.push(qb(a, {
                        url: e,
                        method: 0,
                        templates: c.templates,
                        processResponse: !1,
                        attributionReporting: f.attribution_reporting
                    }))
                }), b.data);
                return Promise.all(d)
            }
        })
    },
    nb = function(a, b, c, d) {
        return d.then(e => {
                const f = a.g.performance.now(),
                    g = [`emkid.${c}~`, `ev.${encodeURIComponent(e.cipherText||"")}`, `&_es=${e.status}`];
                b && f && g.push(`&_est=${Math.round(f)-Math.round(b)}`);
                return g.join("")
            },
            () => [`ec.${Ya(15)}`, "&_es=15"].join("")).catch(() => [`ec.${Ya(16)}`, "&_es=16"].join(""))
    },
    vb = class {
        constructor(a) {
            this.g = a;
            this.h = {
                sha256: b => {
                    const c = this;
                    return h(function*() {
                        return yield ab(b, c.g)
                    })
                },
                encode: b => h(function*() {
                    return encodeURIComponent(b)
                }),
                encrypt: (b, c) => {
                    const d = this;
                    return h(function*() {
                        return yield ob(d, b, c)
                    })
                },
                encryptRsa: (b, c) => {
                    const d = this;
                    return h(function*() {
                        return yield pb(d, b, c)
                    })
                }
            }
        }
    };
class ub extends Error {
    constructor(a) {
        super(a)
    }
};
var xb = function(a, b, c) {
    a.g[b] == null && (a.g[b] = 0, a.h[b] = c, a.j++);
    a.g[b]++;
    return {
        targetId: a.id,
        clientCount: a.j,
        totalLifeMs: Math.round(c - a.v),
        heartbeatCount: a.g[b],
        clientLifeMs: Math.round(c - a.h[b])
    }
};
class yb {
    constructor(a) {
        this.v = a;
        this.g = {};
        this.h = {};
        this.j = 0;
        this.id = String(Math.floor(Number.MAX_SAFE_INTEGER * Math.random()))
    }
}

function zb(a) {
    return a.performance && a.performance.now() || Date.now()
}
var Ab = function(a, b) {
    class c {
        constructor(d, e) {
            this.h = d;
            this.g = e;
            this.j = new yb(zb(e))
        }
        H(d, e) {
            const f = d.clientId;
            if (d.type === 0) d.stats = xb(this.j, f, zb(this.g)), e(d);
            else if (d.type === 1) try {
                this.h(d.command, g => {
                    d.result = g;
                    e(d)
                }, g => {
                    d.failure = g;
                    e(d)
                })
            } catch (g) {
                d.failure = {
                    failureType: 11,
                    data: g.toString()
                }, e(d)
            }
        }
    }
    return new c(a, b)
};
(function(a) {
    a.g.addEventListener("install", () => {
        a.g.skipWaiting()
    });
    a.g.addEventListener("activate", b => {
        b.waitUntil(a.g.clients.claim())
    });
    a.g.addEventListener("message", b => {
        const c = b.source;
        if (c) {
            var d = b.data,
                e = new Promise(f => {
                    a.h.H(d, g => {
                        c.postMessage(g);
                        f(void 0)
                    })
                });
            b.waitUntil(e)
        }
    })
})(new class {
    constructor(a) {
        this.g = a;
        const b = new vb(a);
        this.h = Ab((c, d, e) => {
            tb(b, c, d, e)
        }, a)
    }
}(self));