'use strict';
var k = function(a) {
    function b(c) {
        return a.next(c)
    }

    function e(c) {
        return a.throw(c)
    }
    return new Promise(function(c, d) {
        function f(g) {
            g.done ? c(g.value) : Promise.resolve(g.value).then(b, e).then(f, d)
        }
        f(a.next())
    })
};
/*

 Copyright 2020 Google LLC
 SPDX-License-Identifier: Apache-2.0
*/
function q(a) {
    const b = [];
    let e = 0;
    for (let c = 0; c < a.length; c++) {
        const d = a.charCodeAt(c);
        b[e++] = d
    }
    new Uint8Array(b)
};
/*

 Copyright 2022 Google LLC
 SPDX-License-Identifier: Apache-2.0
*/
v(1, 0);
v(2, 16);
v(2, 18);
v(2, 1);
v(2, 3);
v(2, 1);
v(2, 2);
q("KEM");
q("HPKE");
q("HPKE-v1");

function v(a, b) {
    const e = new Uint8Array(a);
    for (let c = 0; c < a; c++) e[c] = b >> 8 * (a - c - 1) & 255
};
const y = /^[0-9A-Fa-f]{64}$/;

function B(a) {
    try {
        return (new TextEncoder).encode(a)
    } catch (b) {
        const e = [];
        for (let c = 0; c < a.length; c++) {
            let d = a.charCodeAt(c);
            d < 128 ? e.push(d) : d < 2048 ? e.push(192 | d >> 6, 128 | d & 63) : d < 55296 || d >= 57344 ? e.push(224 | d >> 12, 128 | d >> 6 & 63, 128 | d & 63) : (d = 65536 + ((d & 1023) << 10 | a.charCodeAt(++c) & 1023), e.push(240 | d >> 18, 128 | d >> 12 & 63, 128 | d >> 6 & 63, 128 | d & 63))
        }
        return new Uint8Array(e)
    }
}

function F(a, b) {
    if (a === "" || a === "e0") return Promise.resolve(a);
    let e;
    if ((e = b.crypto) == null ? 0 : e.subtle) {
        if (y.test(a)) return Promise.resolve(a);
        try {
            const c = B(a);
            return b.crypto.subtle.digest("SHA-256", c).then(d => {
                const f = Array.from(new Uint8Array(d)).map(g => String.fromCharCode(g)).join("");
                return b.btoa(f).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "")
            }).catch(() => "e2")
        } catch (c) {
            return Promise.resolve("e2")
        }
    } else return Promise.resolve("e1")
};
/*
 jQuery (c) 2005, 2012 jQuery Foundation, Inc. jquery.org/license.
*/
var H = /\[object (Boolean|Number|String|Function|Array|Date|RegExp)\]/,
    I = function(a) {
        var b;
        if (!(b = !a)) {
            var e;
            if (a == null) e = String(a);
            else {
                var c = H.exec(Object.prototype.toString.call(Object(a)));
                e = c ? c[1].toLowerCase() : "object"
            }
            b = e != "object"
        }
        if (b || a.nodeType || a == a.window) return !1;
        try {
            if (a.constructor && !Object.prototype.hasOwnProperty.call(Object(a), "constructor") && !Object.prototype.hasOwnProperty.call(Object(a.constructor.prototype), "isPrototypeOf")) return !1
        } catch (f) {
            return !1
        }
        for (var d in a);
        return d ===
            void 0 || Object.prototype.hasOwnProperty.call(Object(a), d)
    };
var K = function(a, b) {
        b = a.g + b;
        let e = b.indexOf("\n\n");
        for (; e !== -1;) {
            var c = a,
                d;
            a: {
                const [w, r] = b.substring(0, e).split("\n");
                if (w.indexOf("event: message") === 0 && r.indexOf("data: ") === 0) try {
                    d = JSON.parse(r.substring(r.indexOf(":") + 1));
                    break a
                } catch (x) {}
                d = void 0
            }
            var f = c,
                g = d;
            g && (J(g.send_pixel, g.options, f.h), J(g.create_iframe, g.options, f.i), J(g.fetch, g.options, f.j));
            b = b.substring(e + 2);
            e = b.indexOf("\n\n")
        }
        a.g = b
    },
    L = class {
        constructor(a) {
            this.h = a;
            this.g = ""
        }
    };

function J(a, b, e) {
    if (a && e) {
        var c = a || [];
        if (Array.isArray(c)) {
            var d = I(b) ? b : {};
            for (const f of c) e(f, d)
        }
    }
};
var M = {
    m: 0,
    o: 1,
    0: "GET",
    1: "POST"
};
var P = function(a, b) {
        return k(function*() {
            if (!b.url) return {
                failureType: 9,
                command: 0,
                data: "url required."
            };
            const e = yield N(a, b);
            if ("failureType" in e) return e;
            yield O(a, e, b);
            return e
        }())
    },
    Q = function(a, b, e, c) {
        k(function*() {
            let d;
            const f = b.commandType,
                g = b.params;
            switch (f) {
                case 0:
                    d = yield P(a, g);
                    break;
                default:
                    d = {
                        failureType: 8,
                        command: f,
                        data: `Command with type ${f} unknown.`
                    }
            }
            "failureType" in d ? c(d) : e(d)
        }())
    },
    N = function(a, b) {
        return k(function*() {
            function e(h) {
                return k(function*() {
                    const [l, m] = h.split("|");
                    let [z,
                        t
                    ] = l.split("."), n = t, p = w[z];
                    p || (p = l, n = "");
                    const C = u => k(function*() {
                        try {
                            return yield T(m)(u)
                        } catch (A) {
                            throw new R(A.message);
                        }
                    }());
                    if (!n) {
                        if (typeof p === "string") return yield C(p);
                        const u = p,
                            A = Object.keys(u).map(G => k(function*() {
                                const U = yield C(u[G]);
                                return `${G}=${U}`
                            }()));
                        return (yield Promise.all(A)).join("&")
                    }
                    return typeof p === "object" && p[n] ? yield C(p[n]): h
                }())
            }

            function c(h) {
                return k(function*() {
                    let l, m = "";
                    for (; h.match(D) && m !== h;) {
                        m = h;
                        l = h.matchAll(D);
                        const z = [...l].map(n => e(n[1])),
                            t = yield Promise.all(z);
                        t.length !== 0 && (h = h.replace(D, n => t.shift() || n))
                    }
                    return h
                }())
            }
            let {
                url: d,
                body: f
            } = b;
            const {
                attributionReporting: g,
                templates: w,
                processResponse: r,
                method: x = 0
            } = b, D = RegExp("\\${([^${}]*?)}", "g"), T = h => {
                if (h == null) return m => k(function*() {
                    return m
                }());
                const l = a.h[h];
                if (l == null) throw Error(`Unknown filter: ${h}`);
                return m => k(function*() {
                    return yield l(m, b)
                }())
            };
            try {
                d = yield c(d), f = f ? yield c(f): void 0
            } catch (h) {
                return {
                    failureType: 9,
                    command: 0,
                    data: `Failed to inject template values: ${h}`
                }
            }
            const E = {
                method: M[x],
                credentials: "include",
                body: x === 1 ? f : void 0,
                keepalive: !0,
                redirect: "follow"
            };
            r || (E.mode = "no-cors");
            g && (E.attributionReporting = {
                eventSourceEligible: !1,
                triggerEligible: !0
            });
            try {
                const h = yield a.g.fetch(d, E);
                return r && !h.ok ? {
                    failureType: 9,
                    command: 0,
                    data: "Fetch failed"
                } : {
                    data: r ? yield h.text(): d
                }
            } catch (h) {
                return {
                    failureType: 9,
                    command: 0,
                    data: `Fetch failed: ${h}`
                }
            }
        }())
    },
    O = function(a, b, e) {
        return k(function*() {
            if (e.processResponse) {
                var c = [];
                K(new L((d, f) => {
                        c.push(N(a, {
                            url: d,
                            method: 0,
                            templates: e.templates,
                            processResponse: !1,
                            attributionReporting: f.attribution_reporting
                        }))
                    }),
                    b.data);
                return Promise.all(c)
            }
        }())
    },
    S = class {
        constructor(a) {
            this.g = a;
            this.h = {
                sha256: b => {
                    const e = this;
                    return k(function*() {
                        return yield F(b, e.g)
                    }())
                },
                encode: b => k(function*() {
                    return encodeURIComponent(b)
                }()),
                encrypt: () => k(function*() {
                    throw new R("Encryption not supported.");
                }()),
                encryptRsa: () => k(function*() {
                    throw new R("Encryption not supported.");
                }())
            }
        }
    };
class R extends Error {
    constructor(a) {
        super(a)
    }
};
var V = function(a, b, e) {
    a.g[b] == null && (a.g[b] = 0, a.h[b] = e, a.i++);
    a.g[b]++;
    return {
        targetId: a.id,
        clientCount: a.i,
        totalLifeMs: Math.round(e - a.j),
        heartbeatCount: a.g[b],
        clientLifeMs: Math.round(e - a.h[b])
    }
};
class W {
    constructor(a) {
        this.j = a;
        this.g = {};
        this.h = {};
        this.i = 0;
        this.id = String(Math.floor(Number.MAX_SAFE_INTEGER * Math.random()))
    }
}

function X(a) {
    return a.performance && a.performance.now() || Date.now()
}
var Y = function(a, b) {
    class e {
        constructor(c, d) {
            this.h = c;
            this.g = d;
            this.i = new W(X(d))
        }
        l(c, d) {
            const f = c.clientId;
            if (c.type === 0) c.stats = V(this.i, f, X(this.g)), d(c);
            else if (c.type === 1) try {
                this.h(c.command, g => {
                    c.result = g;
                    d(c)
                }, g => {
                    c.failure = g;
                    d(c)
                })
            } catch (g) {
                c.failure = {
                    failureType: 11,
                    data: g.toString()
                }, d(c)
            }
        }
    }
    return new e(a, b)
};
(function(a) {
    a.g.addEventListener("install", () => {
        a.g.skipWaiting()
    });
    a.g.addEventListener("activate", b => {
        b.waitUntil(a.g.clients.claim())
    });
    a.g.addEventListener("message", b => {
        const e = b.source;
        if (e) {
            var c = b.data,
                d = new Promise(f => {
                    a.h.l(c, g => {
                        e.postMessage(g);
                        f(void 0)
                    })
                });
            b.waitUntil(d)
        }
    })
})(new class {
    constructor(a) {
        this.g = a;
        const b = new S(a);
        this.h = Y((e, c, d) => {
            Q(b, e, c, d)
        }, a)
    }
}(self));