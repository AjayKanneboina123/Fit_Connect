window[window["TiktokAnalyticsObject"]]._env = {
    "env": "external",
    "key": ""
};
window[window["TiktokAnalyticsObject"]]._variation_id = 'test_2_single_track';
window[window["TiktokAnalyticsObject"]]._vids = '73586398';
window[window["TiktokAnalyticsObject"]]._cc = 'IN';
window[window.TiktokAnalyticsObject]._li || (window[window.TiktokAnalyticsObject]._li = {}), window[window.TiktokAnalyticsObject]._li["CML2UCRC77UBB48CJFDG"] = "1abd2b31-0dea-11f0-9512-b83fd2cde386";
window[window["TiktokAnalyticsObject"]]._cde = 390;;
if (!window[window["TiktokAnalyticsObject"]]._server_unique_id) window[window["TiktokAnalyticsObject"]]._server_unique_id = '1abd5394-0dea-11f0-9512-b83fd2cde386';
window[window["TiktokAnalyticsObject"]]._plugins = {
    "AdvancedMatching": true,
    "AutoAdvancedMatching": true,
    "AutoConfig": true,
    "Callback": true,
    "DiagnosticsConsole": true,
    "EnrichIpv6": true,
    "EnrichIpv6V2": false,
    "EventBuilder": true,
    "HistoryObserver": true,
    "HitReservoir": true,
    "Identify": true,
    "JSBridge": false,
    "Monitor": false,
    "PageData": false,
    "PangleCookieMatching": true,
    "PerformanceInteraction": false,
    "RuntimeMeasurement": true,
    "Shopify": true,
    "WebFL": false
};
window[window["TiktokAnalyticsObject"]]._aam = {
    "in_form": false,
    "selectors": {
        "[class*=Btn]": 9,
        "[class*=Button]": 11,
        "[class*=btn]": 8,
        "[class*=button]": 10,
        "[id*=Btn]": 14,
        "[id*=Button]": 16,
        "[id*=btn]": 13,
        "[id*=button]": 15,
        "[role*=button]": 12,
        "button[type='button']": 6,
        "button[type='menu']": 7,
        "button[type='reset']": 5,
        "button[type='submit']": 4,
        "input[type='button']": 1,
        "input[type='image']": 2,
        "input[type='submit']": 3
    },
    "exclude_selectors": ["[class*=cancel]", "[role*=cancel]", "[id*=cancel]", "[class*=back]", "[role*=back]", "[id*=back]", "[class*=return]", "[role*=return]", "[id*=return]"],
    "phone_regex": "^\\+?[0-9\\-\\.\\(\\)\\s]{7,25}$",
    "phone_selectors": ["phone", "mobile", "contact", "pn"],
    "restricted_keywords": ["ssn", "unique", "cc", "card", "cvv", "cvc", "cvn", "creditcard", "billing", "security", "social", "pass", "zip", "address", "license", "gender", "health", "age", "nationality", "party", "sex", "political", "affiliation", "appointment", "politics", "family", "parental"]
};
window[window["TiktokAnalyticsObject"]]._auto_config = {
    "open_graph": ["audience"],
    "microdata": ["audience"],
    "json_ld": ["audience"],
    "meta": null
};
! function(i, t, o, n) {
    var e = [{
            id: "MTg3NDRiNWI0MA",
            map: {
                AutoAdvancedMatching: !1,
                Shopify: !1,
                Monitor: !1,
                CompetitorInsight: !1
            }
        }, {
            id: "MTg3NDRiNWI0MQ",
            map: {
                AutoAdvancedMatching: !0,
                Shopify: !1,
                Monitor: !1,
                CompetitorInsight: !1
            }
        }, {
            id: "MTg3NDRiNWI0Mg",
            map: {
                AutoAdvancedMatching: !1,
                Shopify: !0,
                Monitor: !1,
                CompetitorInsight: !1
            }
        }, {
            id: "MTg3NDRiNWI0Mw",
            map: {
                AutoAdvancedMatching: !0,
                Shopify: !0,
                Monitor: !1,
                CompetitorInsight: !1
            }
        }, {
            id: "MTg3NDRiNWI0NA",
            map: {
                AutoAdvancedMatching: !1,
                Shopify: !1,
                Monitor: !0,
                CompetitorInsight: !1
            }
        }, {
            id: "MTg3NDRiNWI0NQ",
            map: {
                AutoAdvancedMatching: !0,
                Shopify: !1,
                Monitor: !0,
                CompetitorInsight: !1
            }
        }, {
            id: "MTg3NDRiNWI0Ng",
            map: {
                AutoAdvancedMatching: !1,
                Shopify: !0,
                Monitor: !0,
                CompetitorInsight: !1
            }
        }, {
            id: "MTg3NDRiNWI0Nw",
            map: {
                AutoAdvancedMatching: !0,
                Shopify: !0,
                Monitor: !0,
                CompetitorInsight: !1
            }
        }, {
            id: "MTg3NDRiNWI0OA",
            map: {
                AutoAdvancedMatching: !1,
                Shopify: !1,
                Monitor: !1,
                CompetitorInsight: !0
            }
        }, {
            id: "MTg3NDRiNWI0OQ",
            map: {
                AutoAdvancedMatching: !0,
                Shopify: !1,
                Monitor: !1,
                CompetitorInsight: !0
            }
        }, {
            id: "MTg3NDRiNWI0MTA",
            map: {
                AutoAdvancedMatching: !1,
                Shopify: !0,
                Monitor: !1,
                CompetitorInsight: !0
            }
        }, {
            id: "MTg3NDRiNWI0MTE",
            map: {
                AutoAdvancedMatching: !0,
                Shopify: !0,
                Monitor: !1,
                CompetitorInsight: !0
            }
        }, {
            id: "MTg3NDRiNWI0MTI",
            map: {
                AutoAdvancedMatching: !1,
                Shopify: !1,
                Monitor: !0,
                CompetitorInsight: !0
            }
        }, {
            id: "MTg3NDRiNWI0MTM",
            map: {
                AutoAdvancedMatching: !0,
                Shopify: !1,
                Monitor: !0,
                CompetitorInsight: !0
            }
        }, {
            id: "MTg3NDRiNWI0MTQ",
            map: {
                AutoAdvancedMatching: !1,
                Shopify: !0,
                Monitor: !0,
                CompetitorInsight: !0
            }
        }, {
            id: "MTg3NDRiNWI0MTU",
            map: {
                AutoAdvancedMatching: !0,
                Shopify: !0,
                Monitor: !0,
                CompetitorInsight: !0
            }
        }],
        a = {
            "info": {
                "pixelCode": "CML2UCRC77UBB48CJFDG",
                "name": "10Web Pixel",
                "status": 0,
                "setupMode": 0,
                "partner": "",
                "advertiserID": "7324706482484953089",
                "is_onsite": false,
                "firstPartyCookieEnabled": true
            },
            "plugins": {
                "Shopify": false,
                "AdvancedMatching": {
                    "email": true,
                    "phone_number": true,
                    "first_name": true,
                    "last_name": true,
                    "city": true,
                    "state": true,
                    "country": true,
                    "zip_code": true
                },
                "AutoAdvancedMatching": {
                    "auto_email": true,
                    "auto_phone_number": true
                },
                "Callback": true,
                "Identify": true,
                "Monitor": true,
                "PerformanceInteraction": true,
                "WebFL": true,
                "AutoConfig": {
                    "form_rules": null,
                    "vc_rules": {}
                },
                "DiagnosticsConsole": true,
                "PangleCookieMatching": false,
                "CompetitorInsight": true,
                "EventBuilder": true,
                "EnrichIpv6": true,
                "HistoryObserver": {
                    "dynamic_web_pageview": true
                },
                "RuntimeMeasurement": true
            },
            "rules": []
        },
        d = "https://analytics.tiktok.com/i18n/pixel/static/",
        i = null == (i = a) || null == (i = i.info) ? void 0 : i.pixelCode;

    function c() {
        return window && window.TiktokAnalyticsObject || "ttq"
    }

    function r() {
        return window && window[c()]
    }

    function p(i, t) {
        t = r()[t];
        return t && t[i] || {}
    }
    var g, M, l = r();
    l || (l = [], window && (window[c()] = l)), Object.assign(a, {
        options: p(i, "_o")
    }), g = a, l._i || (l._i = {}), (M = g.info.pixelCode) && (l._i[M] || (l._i[M] = []), Object.assign(l._i[M], g), l._i[M]._load = +new Date), Object.assign(a.info, {
        loadStart: p(i, "_t"),
        loadEnd: p(i, "_i")._load,
        loadId: l._li && l._li[i] || ""
    }), null != (t = (o = l).instance) && null != (t = t.call(o, i)) && null != (n = t.setPixelInfo) && n.call(t, a.info), g = function(i, t, o) {
        var a = 0 < arguments.length && void 0 !== i ? i : {},
            d = 1 < arguments.length ? t : void 0,
            i = 2 < arguments.length ? o : void 0,
            t = function(i, t) {
                for (var o = 0; o < i.length; o++)
                    if (t.call(null, i[o], o)) return i[o]
            }(e, function(i) {
                for (var t = i.map, o = Object.keys(t), n = function(i) {
                        return !(!a[i] || !d[i]) === t[i]
                    }, e = 0; e < o.length; e++)
                    if (!n.call(null, o[e], e)) return !1;
                return !0
            });
        return t ? "".concat(i, "main.").concat(t.id, ".js") : "".concat(i, "main.").concat(e[0].id, ".js")
    }(l._plugins, a.plugins, d), M = i, (void 0 !== self.DedicatedWorkerGlobalScope ? self instanceof self.DedicatedWorkerGlobalScope : "DedicatedWorkerGlobalScope" === self.constructor.name) ? self.importScripts && self.importScripts(g) : ((o = document.createElement("script")).type = "text/javascript", o.async = !0, o.src = g, o.setAttribute("data-id", M), (g = document.getElementsByTagName("script")[0]) && g.parentNode && g.parentNode.insertBefore(o, g))
}();